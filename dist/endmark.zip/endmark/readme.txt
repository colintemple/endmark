=== Plugin Name ===
Contributors: colintemple	
Donate link: http://colintemple.com/endmark/
Tags: end mark, end of article, symbol	
Requires at least: 2.2.2
Tested up to: 2.8.2
Stable tag: trunk

Endmark adds a trailing symbol to the end of your posts and pages.

== Description ==

Endmark adds a trailing symbol to the end of your posts and pages.

This little bit of typography adds that professional edge to your blog, 
with a magazine-style endmark shown at the end of posts.

You can specify either a character (default is '#') or an image to use.

The default language is English, with localization included for French.


== Installation ==

1. Unzip the `endmark.zip` file
1. Upload `endmark` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to Endmark under Presentation to choose between an image and a link.
